window.PhaserGlobal = { disableWebAudio: true };

var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'phaser-example', { preload: preload, create: create, update: update, render: render});
var floor;
var keys;


function preload() {

   

    //  Firefox doesn't support mp3 files, so use ogg
    game.load.audio('explosie', 'assets/explosie.mp3');
    game.load.audio('cash', 'assets/Cash.mp3');
    game.load.audio('water', 'assets/rivier.mp3');

    game.load.image('button','assets/button.png');
    // game.load.audio('boden', ['assets/audio/time.mp3']);

}

var s;
var music;

function create() {



    game.stage.backgroundColor = '#182d3b';

    explosie = game.add.audio('explosie');
    water = game.add.audio('water');
    cash = game.add.audio('cash');
    explosie.play();

    water.addMarker('water', 0, 90);
    makeButton('water', 500,50);
    makeButton('pause', 300, 50);

    game.input.onDown.add(changeVolume, this);
    floor = new Phaser.Rectangle(0, 200, 800, 50);

    keys = game.input.keyboard.addKeys({ cash: Phaser.Keyboard.ONE, explosie: Phaser.Keyboard.TWO,}); 

    keys.cash.onDown.add(playFx, this);
    keys.explosie.onDown.add(playFx, this);

    water.allowMultiple = false;

}

function update(){
    
}

function makeButton(name, x, y) {

    var button = game.add.button(x, y, 'button', click, this, 0, 1, 2);
    button.name = name;
    button.scale.set(0.5);
    button.smoothed = false;

}

function click(button) {

    if (button.name === 'pause')
    {
        if (water.paused)
        {
            water.resume();
        }
        else
        {
            water.pause();
        }
    }
    else
    {
        water.play(button.name);
    }

}

function changeVolume(pointer) {

    if (pointer.y < 200)
    {
        explosie.pause();
        cash.pause();
    }
    else
    {
        explosie.resume();
        cash.resume();
    }

}

function playFx(key) {

    switch (key.keyCode)
    {
        case Phaser.Keyboard.ONE:
            cash.play();
            break;


        case Phaser.Keyboard.TWO:
            explosie.play();
            break;

        
    }

}

function render(){
    game.debug.geom(floor,'#000');
    game.debug.soundInfo(explosie, 20, 32);
}